BEGIN TRANSACTION;
CREATE TABLE alembic_version (
	version_num VARCHAR(32) NOT NULL, 
	CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
);
INSERT INTO "alembic_version" VALUES('c7d3e4f5a6b7');
CREATE TABLE budget_adjustment (
	project_id VARCHAR(36) NOT NULL, 
	adjustment_date DATE, 
	adjustment_reason VARCHAR(500), 
	adjustment_amount NUMERIC(15, 2) NOT NULL, 
	remark TEXT, 
	id INTEGER NOT NULL, 
	is_deleted BOOLEAN, 
	created_at DATETIME, 
	updated_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(project_id) REFERENCES project (id) ON DELETE RESTRICT
);
CREATE TABLE collection (
	flow_id VARCHAR(36) NOT NULL, 
	collection_date DATE, 
	amount NUMERIC(15, 2) NOT NULL, 
	receipt_no VARCHAR(200), 
	id INTEGER NOT NULL, 
	is_deleted BOOLEAN, 
	created_at DATETIME, 
	updated_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(flow_id) REFERENCES income_flow (id) ON DELETE RESTRICT
);
CREATE TABLE cost_flow (
	order_id VARCHAR(36) NOT NULL, 
	cost_party VARCHAR(200), 
	cost_type VARCHAR(100) NOT NULL, 
	tax_rate NUMERIC(5, 2), 
	taxable_amount NUMERIC(15, 2) NOT NULL, 
	non_taxable_amount NUMERIC(15, 2) NOT NULL, 
	cost_subject VARCHAR(200), 
	budget_item VARCHAR(200), 
	remark TEXT, 
	status VARCHAR(50) NOT NULL, 
	id INTEGER NOT NULL, 
	is_deleted BOOLEAN, 
	created_at DATETIME, 
	updated_at DATETIME, supplier_id INTEGER, 
	PRIMARY KEY (id), 
	FOREIGN KEY(order_id) REFERENCES "order" (id) ON DELETE RESTRICT
);
CREATE TABLE income_flow (
	order_id VARCHAR(36) NOT NULL, 
	invoice_count INTEGER NOT NULL, 
	tax_rate NUMERIC(5, 2), 
	taxable_amount NUMERIC(15, 2) NOT NULL, 
	non_taxable_amount NUMERIC(15, 2) NOT NULL, 
	invoice_date DATE, 
	invoice_no VARCHAR(200), 
	remark TEXT, 
	status VARCHAR(50) NOT NULL, 
	id INTEGER NOT NULL, 
	is_deleted BOOLEAN, 
	created_at DATETIME, 
	updated_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(order_id) REFERENCES "order" (id) ON DELETE RESTRICT
);
CREATE TABLE "order" (
	project_id VARCHAR(36) NOT NULL, 
	supplier_id VARCHAR(36), 
	order_no VARCHAR(100) NOT NULL, 
	order_name VARCHAR(200), 
	order_date DATE, 
	amount NUMERIC(15, 2) NOT NULL, 
	non_tax_amount NUMERIC(15, 2), 
	erp_no VARCHAR(100), 
	mobile_project_no VARCHAR(100), 
	order_type VARCHAR(50), 
	mobile_contact VARCHAR(100), 
	status VARCHAR(50), 
	id INTEGER NOT NULL, 
	is_deleted BOOLEAN, 
	created_at DATETIME, 
	updated_at DATETIME, 
	customer_name VARCHAR(200), 
	PRIMARY KEY (id), 
	UNIQUE (order_no)
);
CREATE TABLE payment (
	cost_id VARCHAR(36) NOT NULL, 
	payment_date DATE, 
	payee VARCHAR(200), 
	voucher_no VARCHAR(200), 
	amount NUMERIC(15, 2) NOT NULL, 
	id INTEGER NOT NULL, 
	is_deleted BOOLEAN, 
	created_at DATETIME, 
	updated_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(cost_id) REFERENCES cost_flow (id) ON DELETE RESTRICT
);
CREATE TABLE project (
	framework_name VARCHAR(200) NOT NULL, 
	sign_date DATE, 
	start_date DATE, 
	end_date DATE, 
	internal_or_external VARCHAR(20) NOT NULL, 
	project_type VARCHAR(100) NOT NULL, 
	is_deleted BOOLEAN, 
	created_at DATETIME, 
	updated_at DATETIME, 
	id INTEGER NOT NULL, 
	PRIMARY KEY (id)
);
INSERT INTO "project" VALUES('多发点','2026-06-04','2026-06-04','2026-06-11','集团内','期货',0,'2026-06-30 01:12:01.010210','2026-06-30 01:12:01.010213',1);
CREATE TABLE project_budget (
	project_id VARCHAR(36) NOT NULL, 
	budget_type VARCHAR(100) NOT NULL, 
	labor_budget NUMERIC(15, 2) NOT NULL, 
	material_budget NUMERIC(15, 2) NOT NULL, 
	management_budget NUMERIC(15, 2) NOT NULL, 
	gross_margin_rate NUMERIC(5, 2), 
	preparation_date DATE, 
	preparer VARCHAR(100), 
	id INTEGER NOT NULL, 
	is_deleted BOOLEAN, 
	created_at DATETIME, 
	updated_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(project_id) REFERENCES project (id) ON DELETE RESTRICT
);
CREATE TABLE supplier (
	name VARCHAR(200) NOT NULL, 
	framework VARCHAR(200), 
	framework_no VARCHAR(100) NOT NULL, 
	framework_start_date DATE, 
	framework_end_date DATE, 
	year INTEGER, 
	id INTEGER NOT NULL, 
	is_deleted BOOLEAN, 
	created_at DATETIME, 
	updated_at DATETIME, 
	PRIMARY KEY (id)
);
INSERT INTO "supplier" VALUES('手机验证登录','苦枯','d23234234','2026-06-30','2026-06-30',NULL,1,0,'2026-06-30 01:12:33.499540','2026-06-30 01:12:33.499544');
CREATE TABLE supplier_contract (
	supplier_id INTEGER NOT NULL, 
	contract_no VARCHAR(100) NOT NULL, 
	sign_date DATE, 
	start_date DATE, 
	end_date DATE, 
	amount NUMERIC(15, 2), 
	status VARCHAR(50), 
	remark TEXT, 
	id INTEGER NOT NULL, 
	is_deleted BOOLEAN, 
	created_at DATETIME, 
	updated_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(supplier_id) REFERENCES supplier (id) ON DELETE RESTRICT, 
	UNIQUE (contract_no)
);
CREATE TABLE supplier_price (
	supplier_id VARCHAR(36) NOT NULL, 
	work_type VARCHAR(100) NOT NULL, 
	unit_price TEXT, 
	remark TEXT, 
	id INTEGER NOT NULL, 
	is_deleted BOOLEAN, 
	created_at DATETIME, 
	updated_at DATETIME, 
	PRIMARY KEY (id)
);
CREATE TABLE supplier_unit_price (
	supplier_id INTEGER NOT NULL, 
	year INTEGER NOT NULL, 
	laborer_price NUMERIC(10, 2), 
	technician_price NUMERIC(10, 2), 
	senior_technician_price NUMERIC(10, 2), 
	special_work_price NUMERIC(10, 2), 
	comprehensive_price NUMERIC(10, 2), 
	remark TEXT, 
	id INTEGER NOT NULL, 
	is_deleted BOOLEAN, 
	created_at DATETIME, 
	updated_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(supplier_id) REFERENCES supplier (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_supplier_unit_year UNIQUE (supplier_id, year)
);
CREATE TABLE supplier_year_price (
	supplier_id VARCHAR(36) NOT NULL, 
	year INTEGER, 
	laborer_unit_price NUMERIC(10, 2), 
	technician_unit_price NUMERIC(10, 2), 
	senior_technician_unit_price NUMERIC(10, 2), 
	special_work_type VARCHAR(100), 
	special_work_price NUMERIC(10, 2), 
	comprehensive_unit_price NUMERIC(10, 2), 
	remark TEXT, 
	id INTEGER NOT NULL, 
	is_deleted BOOLEAN, 
	created_at DATETIME, 
	updated_at DATETIME, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_supplier_year UNIQUE (supplier_id, year)
);
CREATE INDEX ix_supplier_id ON supplier (id);
CREATE INDEX ix_supplier_price_id ON supplier_price (id);
CREATE INDEX ix_supplier_price_supplier_id ON supplier_price (supplier_id);
CREATE INDEX ix_supplier_year_price_id ON supplier_year_price (id);
CREATE INDEX ix_project_id ON project (id);
CREATE INDEX ix_income_flow_id ON income_flow (id);
CREATE INDEX ix_income_flow_order_id ON income_flow (order_id);
CREATE INDEX ix_cost_flow_order_id ON cost_flow (order_id);
CREATE INDEX ix_cost_flow_id ON cost_flow (id);
CREATE INDEX ix_budget_adjustment_id ON budget_adjustment (id);
CREATE INDEX ix_budget_adjustment_project_id ON budget_adjustment (project_id);
CREATE INDEX ix_project_budget_id ON project_budget (id);
CREATE INDEX ix_project_budget_project_id ON project_budget (project_id);
CREATE INDEX ix_collection_flow_id ON collection (flow_id);
CREATE INDEX ix_collection_id ON collection (id);
CREATE INDEX ix_payment_id ON payment (id);
CREATE INDEX ix_payment_cost_id ON payment (cost_id);
CREATE INDEX ix_order_supplier_id ON "order" (supplier_id);
CREATE INDEX ix_order_project_id ON "order" (project_id);
CREATE INDEX ix_order_id ON "order" (id);
CREATE INDEX ix_supplier_contract_id ON supplier_contract (id);
CREATE INDEX ix_supplier_contract_supplier_id ON supplier_contract (supplier_id);
CREATE INDEX ix_supplier_unit_price_id ON supplier_unit_price (id);
CREATE INDEX ix_supplier_unit_price_supplier_id ON supplier_unit_price (supplier_id);
CREATE UNIQUE INDEX uq_supplier_unit_year_active ON supplier_unit_price(supplier_id, year) WHERE is_deleted = 0;
COMMIT;
